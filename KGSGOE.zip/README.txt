Installation instructions KGS Game Objects Editor:

1)Unzip KGSGOE.zip in an empty Folder.
2)Click the .exe //Don't worry it's safe


---###PACKAGE INFO###----
version: 0.0.4(Alpha)
Developper: Josephkhland
Product of KGS

-Notes:
When creating a new character make sure to click refresh.
If you are sure about the changes you have made on something make sure to click on apply before switching to a different object.

In the Current Version: 
-Characters are incomplete and can't be exported 
-Stat Bonuses section from Armors can't be exported.
-Abilities and Misc are Incomplete and not exported.

-Please Report any bugs. 

v0.0.2 Updates:
-Made the use smoother for creating new objects. 
-Refresh button is now pretty much useless and will be removed in future updates, for it's use has been implemented automatically.
-Added Warning Messages when you apply changes to an object. Warning pop-ups when specific values can't be parsed to ints

v0.03 Updates:
-Made Abilities more functional. 
-Added a Warnings List box, warning messages were removed. 
-Added short-keys CTRL +E for export, CTRL + N for Verifying all the files ~ creating warnings if something is wrong.
-Warnings notify you of which values are expected to be Integers. Floats haven't been implemented yet, while some values that might need to be floats give a warning when they can't be parsed to Integers.

v0.0.4 Updates:
-Fixed a small bug with the ability boxes changing all together.
-Fixed the Exportation form.
-Completed the Character Tab and Character Exportation. Still need to create a function to create a character Object out of the stats and everything exported within the DataBase.